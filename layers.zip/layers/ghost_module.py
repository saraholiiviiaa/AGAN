import tensorflow as tf
from tensorflow.keras import layers

class GhostModule(tf.keras.layers.Layer):
    def __init__(self, output_channels, ratio=2, kernel_size=1, dw_kernel_size=3, strides=1, use_relu=True, **kwargs):
        super(GhostModule, self).__init__(**kwargs)
        self.output_channels = output_channels
        self.init_channels = int(output_channels / ratio)
        self.new_channels = output_channels - self.init_channels
        self.primary_conv = tf.keras.Sequential([
            layers.Conv2D(self.init_channels, kernel_size, strides=strides, padding='same', use_bias=False),
            layers.BatchNormalization(),
            layers.ReLU() if use_relu else layers.Activation('linear')
        ])
        self.cheap_operation = tf.keras.Sequential([
            layers.DepthwiseConv2D(dw_kernel_size, strides=1, padding='same', use_bias=False),
            layers.BatchNormalization(),
            layers.ReLU() if use_relu else layers.Activation('linear')
        ])

    def call(self, inputs):
        x1 = self.primary_conv(inputs)
        x2 = self.cheap_operation(x1)
        x = tf.concat([x1, x2[:, :, :, :self.new_channels]], axis=-1)
        return x

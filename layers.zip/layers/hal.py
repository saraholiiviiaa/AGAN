import tensorflow as tf
from tensorflow.keras import layers

class HybridActivationLayer(tf.keras.layers.Layer):
    def __init__(self, **kwargs):
        super(HybridActivationLayer, self).__init__(**kwargs)
        self.relu = layers.ReLU()
        self.sigmoid = layers.Activation('sigmoid')

    def call(self, inputs):
        return self.relu(inputs) * self.sigmoid(inputs)

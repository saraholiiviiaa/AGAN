import tensorflow as tf
from tensorflow.keras import layers

class InputAwareComplexityAdjustment(tf.keras.layers.Layer):
    def __init__(self, **kwargs):
        super(InputAwareComplexityAdjustment, self).__init__(**kwargs)

    def build(self, input_shape):
        self.conv = layers.Conv2D(input_shape[-1], kernel_size=1, strides=1, padding='same')
        self.bn = layers.BatchNormalization()
        self.sigmoid = layers.Activation('sigmoid')

    def call(self, inputs):
        attention = self.sigmoid(self.bn(self.conv(inputs)))
        return inputs * attention

import tensorflow as tf
from tensorflow.keras import layers

class AdaptiveContextualAttention(tf.keras.layers.Layer):
    def __init__(self, reduction=16, **kwargs):
        super(AdaptiveContextualAttention, self).__init__(**kwargs)
        self.reduction = reduction

    def build(self, input_shape):
        channel = input_shape[-1]
        self.global_avg_pool = layers.GlobalAveragePooling2D()
        self.fc1 = layers.Dense(channel // self.reduction, activation='relu')
        self.fc2 = layers.Dense(channel, activation='sigmoid')

    def call(self, inputs):
        x = self.global_avg_pool(inputs)
        x = self.fc1(x)
        x = self.fc2(x)
        x = tf.expand_dims(tf.expand_dims(x, 1), 1)
        return inputs * x
